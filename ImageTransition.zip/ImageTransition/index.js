

const grid = document.querySelector('.grid');
console.log(grid)
// enter button
const enterCtrl = document.querySelector('.content__enter');
console.log(enterCtrl)
// back button
const backCtrl = document.querySelector('.button-back');
console.log(backCtrl)

const images = document.querySelectorAll('.grid__item-img');
console.log(images)

const imageTarget = document.querySelector('.grid__item--target');

const mainImgTarget = document.querySelector('.content__item-img');
console.log(mainImgTarget.style.backgroundImage)

const title = document.querySelector('.content__item-title');



const mainContent = document.querySelector('.content');
enterCtrl.onclick = function () {
    grid.classList.add("grid--open");
    
    console.log(images)
    mainImgTarget.classList.add("main--img--transition")
    enterCtrl.style.display = "none"
    title.style.display = "none"
    images.forEach(element => {
        element.classList.add("img--transition")
    });;
}

backCtrl.onclick = function () {
    images.forEach(element => {
        element.classList.remove("img--transition")
    });;
    mainImgTarget.classList.remove("main--img--transition")
    enterCtrl.style.display = ""
    title.style.display = ""
    grid.classList.remove("grid--open");
    mainContent.classList.remove("content_false");
}